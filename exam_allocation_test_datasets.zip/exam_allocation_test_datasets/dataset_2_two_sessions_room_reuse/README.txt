dataset_2_two_sessions_room_reuse
=================================

Two non-overlapping sittings each exactly match the same usable room capacity, checking room/proctor reuse and candidate non-overlap.

Student rows: 300
Expected usable seats per session after default reserve: 150
Expected result: all candidate-paper rows allocated, no independent check issues, and no unresolved entries.

Notes: Each time slot has 150 student-paper entries and 150 available seats after RM01 is reserved. The same six rooms and six active proctors should be reused at 13:00.

Upload the four CSVs using the matching table types: students.csv, rooms.csv, proctors.csv, equipment.csv. Leave the three contingency-reserve options enabled for the expected result.

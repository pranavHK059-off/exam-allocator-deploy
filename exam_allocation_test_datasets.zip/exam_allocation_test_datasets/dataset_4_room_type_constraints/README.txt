dataset_4_room_type_constraints
===============================

Exact-fit, simultaneous, subject-pure room-type test: standard, quiet, and computer-lab groups must use only compatible rooms.

Student rows: 205
Expected usable seats per session after default reserve: 205
Expected result: all candidate-paper rows allocated, no independent check issues, and no unresolved entries.

Notes: RM01 (50 standard seats) is reserved. Standard demand is 75 (40+35), quiet demand is 75 (30+25+20), and computer-lab demand is 55 (30+25). Seven occupied rooms need seven active proctors.

Upload the four CSVs using the matching table types: students.csv, rooms.csv, proctors.csv, equipment.csv. Leave the three contingency-reserve options enabled for the expected result.

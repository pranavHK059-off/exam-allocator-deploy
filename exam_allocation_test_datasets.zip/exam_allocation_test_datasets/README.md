# Exam Allocation Manager — five exact-fit test datasets

Each subfolder contains the four CSVs required by the app: `students.csv`, `rooms.csv`, `proctors.csv`, and `equipment.csv`. The sets are deliberately built for the default reserve settings (reserve one room, one broadly eligible proctor, and one unit of each equipment type where stock exceeds one).

**Important:** with multiple sessions, seats are reusable after a booking ends. Therefore each dataset is designed so the *concurrent entries in each sitting* equal the usable seating capacity after the app's default room reserve; total rows can exceed total physical seats when rooms are reused across non-overlapping sessions.

## Datasets

1. `dataset_1_exact_fit_mixed_rooms` — small exact fit; varied room capacities; a maintenance room must be ignored.
2. `dataset_2_two_sessions_room_reuse` — two non-overlapping papers for the same 150 candidates; tests room and proctor reuse. Each session exactly matches 150 usable seats.
3. `dataset_3_extra_time_access_and_equipment` — mixed extra time/rest breaks plus laptop and reader requests at exact reserved-stock limits.
4. `dataset_4_room_type_constraints` — simultaneous subject groups restricted to standard, quiet, and computer-lab rooms; each type-specific capacity matches demand.
5. `dataset_5_extreme_full_capacity` — 746 candidates, 25 active rooms after the reserve, and laptop stock exactly matching all usable inventory.

## Expected result

All five datasets are intended to produce zero unresolved entries and zero independent-check issues when run with the revised Python allocation engine, using the default reserve options. The fifth dataset is the main end-to-end stress test.

## How to load

Open one dataset folder and upload its four CSVs to the matching tables in the web app. For a clean repeat, reset/clear existing uploaded tables in the app or re-upload all four tables in that dataset. Do not mix CSVs from different dataset folders.

The data is synthetic, deterministic, and contains no real personal information.

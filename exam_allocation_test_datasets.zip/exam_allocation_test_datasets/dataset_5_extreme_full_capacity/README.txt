dataset_5_extreme_full_capacity
===============================

Extreme-scale exact-fit test with 746 simultaneous candidates, all 25 non-reserved operational rooms, all active seats filled, and laptop stock exactly at usable capacity.

Student rows: 746
Expected usable seats per session after default reserve: 746
Expected result: all candidate-paper rows allocated, no independent check issues, and no unresolved entries.

Notes: Uses the uploaded 28-room layout: 26 rooms are operational, two are in maintenance, and RM01 (50 seats) is held in reserve. The remaining 25 rooms total 746 seats; 26 broad proctors leave 25 active after one is reserved; laptop stock 747 leaves 746 usable after one is reserved.

Upload the four CSVs using the matching table types: students.csv, rooms.csv, proctors.csv, equipment.csv. Leave the three contingency-reserve options enabled for the expected result.

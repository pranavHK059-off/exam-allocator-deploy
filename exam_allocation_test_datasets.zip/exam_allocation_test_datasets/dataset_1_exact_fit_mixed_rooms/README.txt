dataset_1_exact_fit_mixed_rooms
===============================

Exact-fit test with varied room sizes and a maintenance room that must be excluded.

Student rows: 172
Expected usable seats per session after default reserve: 172
Expected result: all candidate-paper rows allocated, no independent check issues, and no unresolved entries.

Notes: Room RM01 (50 seats) is reserved; RM08 is maintenance. The remaining six active rooms total exactly 172 usable seats and need six active proctors.

Upload the four CSVs using the matching table types: students.csv, rooms.csv, proctors.csv, equipment.csv. Leave the three contingency-reserve options enabled for the expected result.

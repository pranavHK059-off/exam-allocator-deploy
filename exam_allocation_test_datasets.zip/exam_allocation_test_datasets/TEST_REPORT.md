# Test execution report

Programmatic checks using `allocation_engine.allocate()` with default reserve settings.

## dataset_1_exact_fit_mixed_rooms
- Student-paper rows: 172
- Unresolved: 0
- Independent audit issues: 0
- Room bookings: 6
- Proctor bookings: 6
- Fully occupied room bookings: 6/6
- Status: PASS

## dataset_2_two_sessions_room_reuse
- Student-paper rows: 300
- Unresolved: 0
- Independent audit issues: 0
- Room bookings: 12
- Proctor bookings: 12
- Fully occupied room bookings: 12/12
- Status: PASS

## dataset_3_extra_time_access_and_equipment
- Student-paper rows: 168
- Unresolved: 0
- Independent audit issues: 0
- Room bookings: 7
- Proctor bookings: 7
- Fully occupied room bookings: 7/7
- Status: PASS

## dataset_4_room_type_constraints
- Student-paper rows: 205
- Unresolved: 0
- Independent audit issues: 0
- Room bookings: 7
- Proctor bookings: 7
- Fully occupied room bookings: 7/7
- Status: PASS

## dataset_5_extreme_full_capacity
- Student-paper rows: 746
- Unresolved: 0
- Independent audit issues: 0
- Room bookings: 25
- Proctor bookings: 25
- Fully occupied room bookings: 25/25
- Status: PASS

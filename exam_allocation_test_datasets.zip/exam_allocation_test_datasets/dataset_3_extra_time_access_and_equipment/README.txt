dataset_3_extra_time_access_and_equipment
=========================================

Exact seat-capacity test with mixed extra time, rest-break allowance, readers, and laptop support; equipment quantities after reserve exactly match demand.

Student rows: 168
Expected usable seats per session after default reserve: 168
Expected result: all candidate-paper rows allocated, no independent check issues, and no unresolved entries.

Notes: RM01 (40 seats) is reserved; the other seven rooms total 168 seats. 36 laptops and 12 reader units are usable after keeping one of each in reserve. Every requested combination should be supplied.

Upload the four CSVs using the matching table types: students.csv, rooms.csv, proctors.csv, equipment.csv. Leave the three contingency-reserve options enabled for the expected result.
